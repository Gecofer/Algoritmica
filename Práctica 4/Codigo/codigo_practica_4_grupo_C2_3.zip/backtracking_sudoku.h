#ifndef _BACKTRANCKING_SUDOKU_H
#define _BACKTRANCKING_SUDOKU_H

#include "sudoku.h"

/**
 * @brief Metodo para resolver un Sudoku
 * @param sudoku Instancia Sudok a resolver
 */
bool resolverSudoku(Sudoku &sudoku);

#endif // _BACKTRANCKING_SUDOKU_H
