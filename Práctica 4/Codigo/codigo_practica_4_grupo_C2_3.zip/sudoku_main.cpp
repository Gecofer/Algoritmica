#include <iostream>
#include "sudoku.h"
#include "backtracking_sudoku.h"

using namespace std;

int main(int argc, char** argv) {

  if (argc < 1) {
		cout << "Debe introducir un fichero de datos" << endl;
		exit(0);
	}

	Sudoku sudoku(argv[1]);

  cout << "ESTADO INICIAL" << endl << sudoku << endl;

	bool solucionado = resolverSudoku(sudoku);

  if(solucionado)
	  cout << "SOLUCION" << endl << sudoku << endl;
  else
    cout << "El sudoku no tiene solución." << endl;

	return 0;
}
