#include "backtracking_sudoku.h"

// Metodo para resolver un Sudoku
bool resolverSudoku(Sudoku &sudoku) {

  // Obtener la siguiente casilla libre.
  Sudoku::Casilla siguiente_casilla = sudoku.getSiguienteCasillaVacia();

  if (siguiente_casilla == Sudoku::NO_LIBRES) {
    return true;
  }

  // Obtener los movimientos disponibles para la siguente casilla.
  Sudoku::NumerosDisponibles numeros = sudoku.getNumerosDisponibles(siguiente_casilla.first, siguiente_casilla.second);

  bool disponible = false;

  // Para cada número disponible probamos a introducirlo ver si nos lleva a la solución
  for (int i = 1; i < numeros.size(); ++i) {
    disponible = numeros[i];

    if (disponible) {
      sudoku.setCasilla(i, siguiente_casilla.first, siguiente_casilla.second);

      if (resolverSudoku(sudoku)) {
        return true;
      }

      sudoku.setCasilla(Sudoku::VACIO, siguiente_casilla.first, siguiente_casilla.second);
    }
  }

  return false;
}
