#include <algorithm>
#include <fstream>
#include "sudoku.h"

// Asignar valor a las constantes static.
const unsigned Sudoku::TAM_CUADRICULA = 9;
const unsigned Sudoku::TAM_SUBCUADRICULA = 3;
const int Sudoku::VACIO = 0;
const Sudoku::Casilla Sudoku::NO_LIBRES(-1, -1);

// Constructor por defecto
Sudoku::Sudoku() {
  // Reservar memoria para la matriz de la cuadricula.
  this->reservarMemoria();
  // Inicializar la cuadricula.
  this->inicializar();
}

// Constructor de copia.
Sudoku::Sudoku(const Sudoku &other) {
  // Copiar los datos de other a esta instancia.
  this->copiar(other);
}

// Constructor mediante archivo
Sudoku::Sudoku(const char* filename) {
  this->reservarMemoria();
  this->cargarArchivo(filename);
}

// Destructor
Sudoku::~Sudoku() {
  // liberar la memoria que haya sido reservada por la instancia.
  this->liberarMemoria();
}

// Operator de asignación.
Sudoku& Sudoku::operator=(const Sudoku &other) {
  // Copiar el contenido del otro Sudoku.
  this->copiar(other);
}

// Getter de una casilla
int Sudoku::getCasilla(unsigned fila, unsigned columna) const {
  return this->cuadricula[fila][columna];
}

// Método para inicializar la cuadricula.
void Sudoku::inicializar() {
  for(int fila = 0; fila < Sudoku::TAM_CUADRICULA; ++fila) {
    for(int columna = 0; columna < Sudoku::TAM_CUADRICULA; ++columna) {
      this->cuadricula[fila][columna] = Sudoku::VACIO;
    }
  }
}

// Método para reservar memoria para la cuadricula.
void Sudoku::reservarMemoria() {
  this->cuadricula = new int*[Sudoku::TAM_CUADRICULA];

  for(int i = 0; i < Sudoku::TAM_CUADRICULA; ++i) {
    this->cuadricula[i] = new int[Sudoku::TAM_CUADRICULA];
  }
}

// Método para liberar la memoria de la cuadricula.
void Sudoku::liberarMemoria() {
  for(int i = 0; i < Sudoku::TAM_CUADRICULA; ++i) {
    delete [] this->cuadricula[i];
  }

  delete [] this->cuadricula;
}

// Método para copiar los datos de otra instancia.
void Sudoku::copiar(const Sudoku &other) {
  // Si la cuadricula no tiene memoria reservada, asignarsela.
  if(this->cuadricula == nullptr) {
    this->reservarMemoria();
  }

  // Copiar los datos de la cuadricula de other a la nuestra con el método Copy
  // de c++11
  for(int i = 0; i < Sudoku::TAM_CUADRICULA; ++i) {

    copy(other.cuadricula[i],
         other.cuadricula[i] + Sudoku::TAM_CUADRICULA,
         this->cuadricula[i]);
  }

}

// Método que carga el archivo del problema
void Sudoku::cargarArchivo(const char* filename){
  int entrada = 0;
	ifstream file (filename);

	// Comprobar que el archivo se ha podido abrir con exito
	if (!file) {
	  cerr << "No se ha podido abrir el archivo " << filename <<  endl;
	  exit(-1);
	}

  for (int i = 0; i < Sudoku::TAM_CUADRICULA; ++i) {
    for (int j = 0; j < Sudoku::TAM_CUADRICULA; ++j) {
      file >> entrada;
      this->setCasilla(entrada, i, j);
    }
  }

  file.close();
}

// Método para obtener los movimientos disponibles para una casilla
Sudoku::NumerosDisponibles Sudoku::getNumerosDisponibles(unsigned fila, unsigned columna) {
  Sudoku::NumerosDisponibles numeros_disponibles = { false, true, true, true, true,
                                                      true, true, true, true, true };

  for (int i = 0; i < Sudoku::TAM_CUADRICULA; ++i) {
    numeros_disponibles[this->getCasilla(fila, i)] = false; // Comprobar en la fila
    numeros_disponibles[this->getCasilla(i, columna)] = false; // Comprobar en la columna
  }

  unsigned fila_subcuadricula = fila - (fila % 3);
  unsigned columna_subcuadricula = columna - (columna % 3);

  int valor = 0;

  // Comprobar en la subcuadricula
  for (int i = 0; i < Sudoku::TAM_SUBCUADRICULA; ++i) {
    for (int j = 0; j < Sudoku::TAM_SUBCUADRICULA; ++j) {
      valor = this->getCasilla(fila_subcuadricula + i, columna_subcuadricula + j );
      numeros_disponibles[valor] = false;
    }
  }

  return numeros_disponibles;
}

// Método para asignar un valor a una casilla seleccionada
bool Sudoku::setCasilla(int valor, unsigned fila, unsigned columna) {
  this->cuadricula[fila][columna] = valor;
}

// Método para obtener la siguiente casilla libre
Sudoku::Casilla Sudoku::getSiguienteCasillaVacia() {
  Sudoku::Casilla casilla(Sudoku::NO_LIBRES);
  bool encontrado = false;

  int valor = -1;

  // Comprobar en la subcuadricula
  for (int i = 0; i < Sudoku::TAM_CUADRICULA && !encontrado; ++i) {
    for (int j = 0; j < Sudoku::TAM_CUADRICULA && !encontrado; ++j) {
      valor = this->getCasilla(i, j);

      if (valor == Sudoku::VACIO) {
        casilla = Sudoku::Casilla(i, j);
        encontrado = true;
      }
    }
  }

  return casilla;
}

// Operador de salida
ostream & operator<<(std::ostream &os, const Sudoku& s) {

    for (int i = 0; i < Sudoku::TAM_CUADRICULA; ++i) {

      os << " -----------------------------------" << endl << "|";

      for(int j = 0; j < Sudoku::TAM_CUADRICULA; ++j) {
        os << " " << s.getCasilla(i, j) << " |";
      }

      os << endl;
    }

    os << " -----------------------------------" << endl;

    return os;
}
