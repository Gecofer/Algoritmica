#ifndef _SUDOKU_H_
#define _SUDOKU_H_

#include <vector>
#include <iostream>

using namespace std;

class Sudoku {

public:

  // Tipo definido para los momivientos.
  typedef vector<bool> NumerosDisponibles;
  typedef pair<int, int> Casilla;

  // Constantes static
  static const unsigned TAM_CUADRICULA;
  static const unsigned TAM_SUBCUADRICULA;
  static const int VACIO;
  static const Casilla NO_LIBRES;

  /**
  *  * @brief Constructor por defecto.
  */
  Sudoku();

  /**
  * @brief Constructor desde fichero.
  * @param file Ruta de archivo con los datos del Sudoku
  */
  Sudoku(const char* file);

  /**
  * @brief Constructor de copia
  * @param other Instancia de la clase Sudoku a copiar.
  */
  Sudoku(const Sudoku &other);

  /**
  * @brief Destructor
  */
  ~Sudoku();

  /**
   * @brief Método para cargar un sudoku desde un archivo.
   * @param filename nombre del archivo del cual leer el suduko.
   */
  void cargarArchivo(const char* filename);

  /**
  * @brief Getter para obtener el valor de una casilla de la cuadricula.
  * @param fila Fila de la que queremos obtener el valor
  * @param columna Columna de la que queremos obtener el valor
  * @return Valor en la casilla seleccionada.
  */
  int getCasilla(unsigned fila, unsigned columna) const;

  /**
  * @brief Método para asignar un valor a una casilla seleccionada.
  * @param valor Valor a asignar a la casilla.
  * @param fila Fila de la que queremos modificar el valor
  * @param columna Columna de la que queremos modificar el valor
  * @return True, si ha podido insertar según las reglas del Sudoku, false en
  * caso contrario.
  */
  bool setCasilla(int valor, unsigned fila, unsigned columna);

  /**
  * @brief Método para obtener los numeros disponibles para una casilla.
  * @param fila Fila de la que queremos los numeros disponibles.
  * @param columna Columna de la que queremos los numeros disponibles.
  * @return Vector con los numeros disponibles.
  */
  NumerosDisponibles getNumerosDisponibles(unsigned fila, unsigned columna);

  /**
  * @brief Operador de asignación.
  * @param other Instancia de la que copiar sus contenidos.
  * @return instancia de este mismo objeto.
  */
  Sudoku& operator=(const Sudoku &other);

  /**
   * @brief Método para conseguir la siguiente casilla libre.
   * @return Primera casilla libre encontrada o [-1,-1] si no hay casillas libres.
   */
   Casilla getSiguienteCasillaVacia();

private:

  int **cuadricula = nullptr;

  /**
   * @brief operador de salida.
   * @param os flujo de salida.
   * @param s sudoku a imprimir al flujo de salida.
   * @return flujo de salida
   */
  friend ostream & operator<<(std::ostream &os, const Sudoku& s);

  /**
  * @brief Método para inicializar toda la cuadricula con casillas vacias.
  */
  void inicializar();

  /**
  * @brief Método para reservar memoria para la cuadricula
  */
  void reservarMemoria();

  /**
  * @brief Método para liberar la memoria reservada por el objeto.
  */
  void liberarMemoria();

  /**
  * @brief Método para copiar los contenidos de una instancia de Sudoku al local
  * @param other Instancia de la clase Sudoku a copiar.
  */
  void copiar(const Sudoku &other);

};
#endif // _SUDOKU_H_
